import { ComponentFixture, TestBed } from '@angular/core/testing';

import { GlassPrescriptionAxisMasterComponent } from './glass-prescription-axis-master.component';

describe('GlassPrescriptionAxisMasterComponent', () => {
  let component: GlassPrescriptionAxisMasterComponent;
  let fixture: ComponentFixture<GlassPrescriptionAxisMasterComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [GlassPrescriptionAxisMasterComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(GlassPrescriptionAxisMasterComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
