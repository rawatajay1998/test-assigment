import { Component, OnInit } from '@angular/core';
import { GlassPrescriptionAxisService } from '../../services/glass-prescription-axis-master';
import { NgFor } from '@angular/common';
import { GlassPrescribtionAxisData } from '../../models/glass-prescribtion-axis-data.model';

@Component({
  selector: 'app-glass-prescription-axis-master',
  standalone: true,
  imports: [NgFor],
  templateUrl: './glass-prescription-axis-master.component.html',
  styleUrl: './glass-prescription-axis-master.component.css',
})
export class GlassPrescriptionAxisMasterComponent implements OnInit {
  dataArray: GlassPrescribtionAxisData[] = [];

  constructor(
    private glassPrescribtionAxisData: GlassPrescriptionAxisService
  ) {}

  ngOnInit(): void {
    this.glassPrescribtionAxisData.getData().subscribe((res) => {
      this.dataArray = res.data;
    });
  }
}
