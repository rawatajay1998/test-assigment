import { Routes } from '@angular/router';
import { LoginComponent } from './auth/login/login.component';
import { GlassPrescriptionAxisMasterComponent } from './pages/glass-prescription-axis-master/glass-prescription-axis-master.component';
import { authGuard } from './auth.guard';
import { LayoutComponent } from './shared/layout/layout.component';

export const routes: Routes = [
  {
    path: '',
    redirectTo: '/login',
    pathMatch: 'full',
  },
  {
    path: 'login',
    component: LoginComponent,
  },
  {
    path: '',
    component: LayoutComponent,
    children: [
      {
        path: 'glass-prescription-axis-master',
        component: GlassPrescriptionAxisMasterComponent,
        canActivate: [authGuard],
      },
    ],
  },
];
