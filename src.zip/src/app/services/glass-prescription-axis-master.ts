import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { BaseUrl } from '../../environment';

@Injectable({
  providedIn: 'root',
})
export class GlassPrescriptionAxisService {
  constructor(private http: HttpClient) {}

  getData(): Observable<any> {
    return this.http.get<any>(
      `${BaseUrl}GlassPrescriptionAxisMaster/GetGlassPrescriptionAxisMasterList`
    );
  }
}
