import { GlassPrescribtionAxisData } from './glass-prescribtion-axis-data.model';

describe('GlassPrescribtionAxisData', () => {
  it('should create an instance', () => {
    expect(new GlassPrescribtionAxisData()).toBeTruthy();
  });
});
