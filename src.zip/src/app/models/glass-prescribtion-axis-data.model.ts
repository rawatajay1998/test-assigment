export class GlassPrescribtionAxisData {
  'slNo': Number;
  'glassPrescriptionAxisId': Number;
  'glassPrescriptionAxisName': String;
  'isActive': boolean;
  'createdBy': string;
  'createdByName': string;
  'createdOn': string;
  'updatedOn': string;
}
