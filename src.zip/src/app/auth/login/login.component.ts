import { HttpClient } from '@angular/common/http';
import { Component, inject, Input, Signal, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { BaseUrl } from '../../../environment';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login',
  standalone: true,
  imports: [FormsModule],
  templateUrl: './login.component.html',
  styleUrl: './login.component.css',
})
export class LoginComponent {
  constructor(private router: Router) {}

  step: Number = 1;
  isSuccess: Boolean = false;
  deptObj: any = {
    mobileNo: '',
  };

  verifyOtpObj: any = {
    mobileNo: '',
    otp: '',
  };

  http = inject(HttpClient);

  onEnterMobile() {
    this.http
      .post(`${BaseUrl}Account/SendOtp`, this.deptObj)
      .subscribe((res: any) => {
        console.log(res.data.otp);

        if ((res.ok = true)) {
          this.step = 2;
        }
      });
  }
  onVerifyOtp() {
    this.http
      .post(`${BaseUrl}Account/VerifyOtp`, this.verifyOtpObj)
      .subscribe((res: any) => {
        sessionStorage.setItem('accesstoken', res.token);
        this.router.navigate(['glass-prescription-axis-master']);
      });
  }
}
